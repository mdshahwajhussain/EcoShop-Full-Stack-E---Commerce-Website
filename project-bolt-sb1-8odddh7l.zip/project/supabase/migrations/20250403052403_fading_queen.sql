/*
  # Add smartphone and accessory products

  1. Changes
    - Insert new products into the products table including:
      - Smartphones
      - Phone cases
      - Chargers
      - Earbuds
      - Screen protectors
*/

INSERT INTO products (name, description, price, image_url, stock)
VALUES
  (
    'iPhone 15 Pro',
    'Latest iPhone with A17 Pro chip, 48MP camera system, and titanium design',
    999.99,
    'https://images.unsplash.com/photo-1695048133142-1a20484d2569',
    50
  ),
  (
    'Samsung Galaxy S24 Ultra',
    'Premium Android phone with S Pen, 200MP camera, and AI features',
    1199.99,
    'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf',
    45
  ),
  (
    'Google Pixel 8 Pro',
    'Advanced AI photography, clean Android experience, and great battery life',
    899.99,
    'https://images.unsplash.com/photo-1598327105666-5b89351aff97',
    30
  ),
  (
    'Premium Leather Phone Case',
    'Genuine leather case with card slots and premium finish',
    49.99,
    'https://images.unsplash.com/photo-1541877944-ac135a598d05',
    100
  ),
  (
    'Fast Wireless Charger',
    '15W Qi wireless charging pad with LED indicator',
    29.99,
    'https://images.unsplash.com/photo-1622959588581-627e8977d24a',
    150
  ),
  (
    'Noise-Cancelling Earbuds',
    'True wireless earbuds with active noise cancellation and 24h battery life',
    149.99,
    'https://images.unsplash.com/photo-1590658268037-6bf12165a8df',
    75
  ),
  (
    'Tempered Glass Screen Protector',
    '9H hardness screen protector with oleophobic coating',
    19.99,
    'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb',
    200
  ),
  (
    'USB-C Power Bank',
    '20000mAh portable charger with fast charging support',
    59.99,
    'https://images.unsplash.com/photo-1609592786331-047e68d6c769',
    80
  ),
  (
    'Phone Camera Lens Kit',
    'Professional 3-in-1 lens kit including wide-angle, macro, and fisheye',
    79.99,
    'https://images.unsplash.com/photo-1617775047746-5b36a40109f5',
    40
  ),
  (
    'Phone Ring Holder & Stand',
    '360-degree rotating ring grip with car mount compatibility',
    14.99,
    'https://images.unsplash.com/photo-1586105251261-72a756497a11',
    120
  );