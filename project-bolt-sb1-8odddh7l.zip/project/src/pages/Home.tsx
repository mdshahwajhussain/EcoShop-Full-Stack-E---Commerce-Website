import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag } from 'lucide-react';

function Home() {
  return (
    <div className="text-center">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">
          Welcome to EcoShop
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Discover our curated collection of sustainable products
        </p>
        <Link
          to="/products"
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <ShoppingBag className="mr-2 h-5 w-5" />
          Start Shopping
        </Link>
      </div>
      
      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <img
            src="https://images.unsplash.com/photo-1542291026-7eec264c27ff"
            alt="Featured Product"
            className="w-full h-48 object-cover rounded-md mb-4"
          />
          <h3 className="text-lg font-semibold">Latest Arrivals</h3>
          <p className="text-gray-600">Check out our newest products</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <img
            src="https://images.unsplash.com/photo-1523275335684-37898b6baf30"
            alt="Special Offers"
            className="w-full h-48 object-cover rounded-md mb-4"
          />
          <h3 className="text-lg font-semibold">Special Offers</h3>
          <p className="text-gray-600">Great deals on selected items</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <img
            src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e"
            alt="Collections"
            className="w-full h-48 object-cover rounded-md mb-4"
          />
          <h3 className="text-lg font-semibold">Collections</h3>
          <p className="text-gray-600">Curated sets for every need</p>
        </div>
      </div>
    </div>
  );
}

export default Home;